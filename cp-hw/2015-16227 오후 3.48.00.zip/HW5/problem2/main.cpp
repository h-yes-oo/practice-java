#include <iostream>
#include <string>
#include <utility>
#include <set>
#include <vector>
#include <tuple>
#include <math.h>
#include <algorithm>

/* =======START OF PRIME-RELATED HELPERS======= */
/*
 * The code snippet below AS A WHOLE does the primality
 * test and integer factorization. Feel free to move the
 * code to somewhere more appropriate to get your codes
 * more structured.
 *
 * You don't have to understand the implementation of it.
 * But if you're curious, refer to the sieve of Eratosthenes
 *
 * If you want to just use it, use the following 2 functions.
 *
 * 1) bool is_prime(int num):
 *     * `num` should satisfy 1 <= num <= 999999
 *     - returns true if `num` is a prime number
 *     - returns false otherwise (1 is not a prime number)
 *
 * 2) std::multiset<int> factorize(int num):
 *     * `num` should satisfy 1 <= num <= 999999
 *     - returns the result of factorization of `num`
 *         ex ) num = 24 --> result = { 2, 2, 2, 3 }
 *     - if `num` is 1, it returns { 1 }
 */

const int PRIME_TEST_LIMIT = 999999;
int sieve_of_eratosthenes[PRIME_TEST_LIMIT + 1];
bool sieve_calculated = false;

void make_sieve() {
    sieve_of_eratosthenes[0] = -1;
    sieve_of_eratosthenes[1] = -1;
    for(int i=2; i<=PRIME_TEST_LIMIT; i++) {
        sieve_of_eratosthenes[i] = i;
    }
    for(int i=2; i*i<=PRIME_TEST_LIMIT; i++) {
        if(sieve_of_eratosthenes[i] == i) {
            for(int j=i*i; j<=PRIME_TEST_LIMIT; j+=i) {
                sieve_of_eratosthenes[j] = i;
            }
        }
    }
    sieve_calculated = true;
}

bool is_prime(int num) {
    if (!sieve_calculated) {
        make_sieve();
    }
    return sieve_of_eratosthenes[num] == num;
}

std::multiset<int> factorize(int num) {
    if (!sieve_calculated) {
        make_sieve();
    }
    std::multiset<int> result;
    while(num > 1) {
        result.insert(sieve_of_eratosthenes[num]);
        num /= sieve_of_eratosthenes[num];
    }
    if(result.empty()) {
        result.insert(1);
    }
    return result;
}

/* =======END OF PRIME-RELATED HELPERS======= */

/* =======START OF std::string LITERALS======= */
/* Use this code snippet if you want */

const std::string MAXIMIZE_GAIN = "Maximize-Gain";
const std::string MINIMIZE_LOSS = "Minimize-Loss";
const std::string MINIMIZE_REGRET = "Minimize-Regret";

/* =======END OF std::string LITERALS======= */


/* =======START OF TODOs======= */

std::pair<int, int> number_fight(int a, int b) {
    std::multiset<int> FA = factorize(a);
    std::multiset<int> FB = factorize(b);
    std::set<int> FG;
    set_intersection(FA.begin(),FA.end(),FB.begin(),FB.end(),std::inserter(FG,FG.begin()));
    int G = 1;
    for(int n : FG) {
        G = G * n;
    }
    std::pair<int,int> result = std::make_pair(a/G,b/G);
    return result;
}

std::pair<int, int> number_vs_number(int a, int b) {
    std::pair<int,int> fight = number_fight(a,b);
    int aPrime = fight.first;
    int bPrime = fight.second;
    int aAttacks = b - bPrime;
    int bAttacks = a - aPrime;
    int sevenFlagOfA = factorize(a).count(7);
    int sevenFlagOfB = factorize(b).count(7);
    std::pair<int,int> aAttacksB;
    if(sevenFlagOfB>0){
        int valA = a-(int)floor(aAttacks/2);
        int valB = b-(int)floor(aAttacks/2);
        aAttacksB = std::make_pair(valA>=1?valA:1,valB>=1?valB:1);
    } else{
        aAttacksB = std::make_pair(a,b-aAttacks);
    }
    std::pair<int,int> bAttacksA;
    if(sevenFlagOfA>0){
        int valA = a-(int)floor(bAttacks/2);
        int valB = b-(int)floor(bAttacks/2);
        bAttacksA =std::make_pair(valA>=1?valA:1,valB>=1?valB:1);
    } else{
        bAttacksA =std::make_pair(a-bAttacks,b);
    }
    std::pair<int,int> noFight = std::make_pair(a,b);
    int AifB = (fight.first >= bAttacksA.first)? 1 : 0;
    int AifnotB = (aAttacksB.first >= noFight.first)? 1 : 0;
    int A;
    if(AifB == AifnotB){
        A = AifB;
    } else{
        A = (b>a)? 1: 0;
    }
    int BifA = (fight.second >= aAttacksB.second );
    int BifnotA = (bAttacksA.second >= noFight.second);
    int B;
    if(BifA == BifnotA){
        B = BifA;
    } else{
        B = (a>b)? 1: 0;
    }
    if(A > 0){
        if(B>0) return fight;
        else return aAttacksB;
    } else{
        if(B>0) return bAttacksA;
        else return noFight;
    }
}

int makechoice(std::string type_a,std::multiset<int> a,std::multiset<int> b,int** Atable){
    int choiceOfA = 0;
    if(type_a.compare("Maximize-Gain")==0){
        int max_gain = Atable[0][0];
        for(int i = 0; i<a.size();i++){
            for(int j = 0; j<b.size();j++){
                if(Atable[i][j]>max_gain){
                    max_gain = Atable[i][j];
                    choiceOfA = i;
                }
            }
        }

    } else if(type_a.compare("Minimize-Loss")==0){
        int* lossArray = new int[a.size()];
        for(int i = 0; i<a.size();i++){
            int max_loss = Atable[i][0];
            for(int j = 0; j<b.size();j++){
                if(Atable[i][j]<max_loss){
                    max_loss = Atable[i][j];
                }
            }
            lossArray[i] = max_loss;
        }
        int max_loss_total = lossArray[0];
        for(int i=0; i<a.size();i++){
            if(lossArray[i]>max_loss_total){
                max_loss_total = lossArray[i];
                choiceOfA = i;
            }
        }

    }else if(type_a.compare("Minimize-Regret")==0){
        if(a.size()==1) return 0;
        int* regretArray = new int[a.size()];
        for(int i = 0; i<a.size();i++){
            int max_loss = Atable[i][0];
            for(int j = 0; j<b.size();j++){
                if(Atable[i][j]<max_loss){
                    max_loss = Atable[i][j];
                }
            }
            int max_gain = (i==0)? Atable[1][0]: Atable[0][0];
            for(int k = 0; k<a.size();k++){
                if(k != i) {
                    for (int j = 0; j < b.size(); j++) {
                        if (Atable[k][j] > max_gain) {
                            max_gain = Atable[k][j];
                        }
                    }
                }
            }
            int regret = max_gain - max_loss;
            regretArray[i] = regret;
        }
        int min_regret = regretArray[0];
        for(int i=0; i<a.size();i++){
            if(regretArray[i]<min_regret){
                min_regret = regretArray[i];
                choiceOfA = i;
            }
        }
    }
    return choiceOfA;
}

int choiceB(std::string type_a,std::multiset<int> a,std::multiset<int> b,int** Atable){
    int choiceOfA = 0;
    if(type_a.compare("Maximize-Gain")==0){
        int max_gain = Atable[0][0];
        for(int j = 0; j<b.size();j++){
            for(int i = 0; i<a.size();i++){
                if(Atable[i][j]>max_gain){
                    max_gain = Atable[i][j];
                    choiceOfA = j;
                }
            }
        }

    } else if(type_a.compare("Minimize-Loss")==0){
        int* lossArray = new int[b.size()];
        for(int j = 0; j<b.size();j++){
            int max_loss = Atable[0][j];
            for(int i = 0; i<a.size();i++){
                if(Atable[i][j]<max_loss){
                    max_loss = Atable[i][j];
                }
            }
            lossArray[j] = max_loss;
        }
        int max_loss_total = lossArray[0];
        for(int i=0; i<b.size();i++){
            if(lossArray[i]>max_loss_total){
                max_loss_total = lossArray[i];
                choiceOfA = i;
            }
        }

    }else if(type_a.compare("Minimize-Regret")==0){
        if(b.size()==1) return 0;
        int* regretArray = new int[b.size()];
        for(int j = 0; j<b.size();j++){
            int max_loss = Atable[0][j];
            for(int i = 0; i<a.size();i++){
                if(Atable[i][j]<max_loss){
                    max_loss = Atable[i][j];
                }
            }
            int max_gain = (j==0)? Atable[0][1]: Atable[0][0];
            for(int k = 0; k<b.size();k++){
                if(k != j) {
                    for (int i = 0; i < a.size(); i++) {
                        if (Atable[i][k] > max_gain) {
                            max_gain = Atable[i][k];
                        }
                    }
                }
            }
            int regret = max_gain - max_loss;
            regretArray[j] = regret;
        }
        int min_regret = regretArray[0];
        for(int i=0; i<b.size();i++){
            if(regretArray[i]<min_regret){
                min_regret = regretArray[i];
                choiceOfA = i;
            }
        }
    }
    return choiceOfA;
}

std::pair<std::multiset<int>, std::multiset<int>> player_battle(
    std::string type_a, std::multiset<int> a, std::string type_b, std::multiset<int> b
) {
    int* arrayOfA = new int[a.size()];
    int i=0;
    std::multiset<int>::const_iterator pos;
    for(pos=a.begin(); pos != a.end(); ++pos){
        arrayOfA[i] = *pos;
        i++;
    }

    int* arrayOfB = new int[b.size()];
    int j=0;
    std::multiset<int>::const_iterator pos2;
    for(pos2=b.begin(); pos2 != b.end(); ++pos2){
        arrayOfB[j] = *pos2;
        j++;
    }

    std::sort(arrayOfA,arrayOfA+a.size());
    std::sort(arrayOfB,arrayOfB+b.size());

    std::pair<int,int> ** table = new std::pair<int,int> * [a.size()];
    for(int i = 0; i<a.size();i++){
        table[i] = new std::pair<int,int>[b.size()];
        for(int j=0 ; j<b.size();j++){
            table[i][j] = number_vs_number(arrayOfA[i],arrayOfB[j]);
//            std::cout<<"table"<<i<<j<<" first: " << table[i][j].first<<std::endl;
//            std::cout<<"table"<<i<<j<<" second: " << table[i][j].second<<std::endl;
        }
    }

    int ** Atable = new int * [a.size()];
    for(int i = 0; i<a.size();i++){
        Atable[i] = new int[b.size()];
        for(int j=0 ; j<b.size();j++){
            Atable[i][j] = table[i][j].first-arrayOfA[i];
//            std::cout<<"Atable"<<i<<j<<" : " << Atable[i][j]<<std::endl;
        }
    }


    int ** Btable = new int * [a.size()];
    for(int i = 0; i<a.size();i++){
        Btable[i] = new int[b.size()];
        for(int j=0 ; j<b.size();j++){
            Btable[i][j] = table[i][j].second-arrayOfB[j];
//            std::cout<<"Btable"<<i<<j<<" : " << Btable[i][j]<<std::endl;
        }
    }

    int choiceOfA = makechoice(type_a,a,b,Atable);
    int choiceOfB = choiceB(type_b,a,b,Btable);

    int changedA = table[choiceOfA][choiceOfB].first;
    int changedB = table[choiceOfA][choiceOfB].second;

    arrayOfA[choiceOfA] = changedA;
    arrayOfB[choiceOfB] = changedB;
//    std::cout<<"choiceOfA"<<choiceOfA<<std::endl;
//    std::cout<<"choiceofB"<<choiceOfB<<std::endl;

    int sizeOfA = a.size();
    int sizeOfB = b.size();
    a.clear();
    for(int i =0; i< sizeOfA; i++){
        a.insert(arrayOfA[i]);
    }
    b.clear();
    for(int i=0; i< sizeOfB;i++){
        b.insert(arrayOfB[i]);
    }

    return std::make_pair(a,b);
}

bool equality_check(std::multiset<int> original, std::multiset<int> afterFight){
    int size=original.size();
    if(size != afterFight.size()) return false;
    int* originalArray = new int[size];
    int* afterArray = new int[size];
    int i=0;
    std::multiset<int>::const_iterator pos;
    for(pos=afterFight.begin(); pos != afterFight.end(); ++pos){
        afterArray[i] = *pos;
        i++;
    }
    int j=0;
    std::multiset<int>::const_iterator pos2;
    for(pos2=original.begin(); pos2 != original.end(); ++pos2){
        originalArray[j] = *pos2;
        j++;
    }
    std::sort(originalArray,originalArray+size);
    std::sort(afterArray,afterArray+size);
    for(int k = 0; k<size;k++){
        if(originalArray[k]!=afterArray[k]) return false;
    }
    return true;
}

std::pair<std::multiset<int>, std::multiset<int>> player_vs_player(
    std::string type_a, std::multiset<int> a, std::string type_b, std::multiset<int> b
) {
    int num = 0;
    std::multiset<int> fightA = a;
    std::multiset<int> fightB = b;
    while(true){
        std::pair<std::multiset<int>, std::multiset<int>> fight = player_battle(type_a,fightA,type_b,fightB);
        if(equality_check(fightA,fight.first) && equality_check(fightB,fight.second)){
            return std::make_pair(fightA,fightB);
        }
        fightA = fight.first;
        fightB = fight.second;
        num++;
    }
}

int tournament(std::vector<std::pair<std::string, std::multiset<int>>> players) {
    int size = players.size();
    std::string* typeArray = new std::string[size];
    std::multiset<int>* cardsetArray = new std::multiset<int>[size];
    int* winners = new int[size];
    int i = 0;
    for(std::pair pair : players){
        typeArray[i] = pair.first;
        i++;
    }
    i = 0;
    for(std::pair pair : players){
        cardsetArray[i] = pair.second;
        i++;
    }
    for(int j = 0; j<size;j++){
        winners[j]=j;
    }
    for(int i = size; i>1; i= i/2){
        if(i%2==0) {
            int* postWinners = new int[i/2];
            for (int j = 0; j < i; j += 2) {
                int firstPlayer = winners[j];
                int secondPlayer = winners[j + 1];
                std::pair<std::multiset<int>, std::multiset<int>> fight = player_vs_player(typeArray[firstPlayer],cardsetArray[firstPlayer],typeArray[secondPlayer],cardsetArray[secondPlayer]);
                int sumOfFirst = 0;
                for(int elem : fight.first){
                    sumOfFirst += elem;
                }

                int sumOfsecond = 0;
                for(int elem : fight.second){
                    sumOfsecond += elem;
                }
                postWinners[j/2] = (sumOfFirst>=sumOfsecond)? firstPlayer : secondPlayer;
            }
            winners = postWinners;
        } else{
            int* postWinners = new int[i/2+1];
            for (int j = 0; j < i-1; j += 2) {
                int firstPlayer = winners[j];
                int secondPlayer = winners[j + 1];
                std::pair<std::multiset<int>, std::multiset<int>> fight = player_vs_player(typeArray[firstPlayer],cardsetArray[firstPlayer], typeArray[secondPlayer], cardsetArray[secondPlayer]);
                int sumOfFirst = 0;
                for (int elem : fight.first) {
                    sumOfFirst += elem;
                }
                int sumOfsecond = 0;
                for (int elem : fight.second) {
                    sumOfsecond += elem;
                }
                postWinners[j / 2] = (sumOfFirst >= sumOfsecond) ? firstPlayer : secondPlayer;
            }
            postWinners[i/2]=winners[i-1];
            winners = postWinners;
            i++;
        }
    }
    return winners[0];
}

int steady_winner(std::vector<std::pair<std::string, std::multiset<int>>> players) {
    int numOfTournaments = players.size();
    int* winners = new int[numOfTournaments];
    int* counts = new int[numOfTournaments];
    for(int i =0; i<numOfTournaments;i++){
        int winner = tournament(players) + i;
        winners[i] = (winner>=numOfTournaments)? winner - numOfTournaments : winner;
        players.push_back(players[0]);
        players.erase(players.begin());
    }
    for(int i =0; i<numOfTournaments;i++){
        counts[winners[i]]++;
    }
    int theSteadyWinner = 0;
    int maxWinningCount = 0;
    for(int i =0; i<numOfTournaments;i++){
        if(counts[i] > maxWinningCount){
            maxWinningCount = counts[i];
            theSteadyWinner = i;
        }
    }
    return theSteadyWinner;
}

/* =======END OF TODOs======= */

/* =======START OF THE MAIN CODE======= */
/* Please do not modify the code below */

typedef std::pair<std::string, std::multiset<int>> player;

player scan_player() {
    std::multiset<int> numbers;
    std::string player_type; int size;
    std::cin >> player_type >> size;
    for(int i=0;i<size;i++) {
        int t; std::cin >> t; numbers.insert(t);
    }
    return make_pair(player_type, numbers);
}

void print_multiset(const std::multiset<int>& m) {
    for(int number : m) {
        std::cout << number << " ";
    }
    std::cout << std::endl;
}

int main() {
    while (true) {
        int question_number;
        std::cin >> question_number;
        if (question_number == 1) {
            int a, b;
            std::cin >> a >> b;
            std::tie(a, b) = number_fight(a, b);
            std::cout << a << " " << b << std::endl;
        } else if (question_number == 2) {
            int a, b;
            std::cin >> a >> b;
            std::tie(a, b) = number_vs_number(a, b);
            std::cout << a << " " << b << std::endl;
        } else if (question_number == 3 || question_number == 4) {
            auto a = scan_player();
            auto b = scan_player();
            std::multiset<int> a_, b_;
            if (question_number == 3) {
                tie(a_, b_) = player_battle(
                        a.first, a.second, b.first, b.second
                );
            } else {
                tie(a_, b_) = player_vs_player(
                        a.first, a.second, b.first, b.second
                );
            }
            print_multiset(a_);
            print_multiset(b_);
        } else if (question_number == 5 || question_number == 6) {
            int num_players;
            std::cin >> num_players;
            std::vector<player> players;
            for (int i = 0; i < num_players; i++) {
                players.push_back(scan_player());
            }
            int winner_id;
            if (question_number == 5) {
                winner_id = tournament(players);
            } else {
                winner_id = steady_winner(players);
            }
            std::cout << winner_id << std::endl;
        } else {
            return 0;
        }
    }
    return 0;
}
/* =======END OF MAIN CODE======= */
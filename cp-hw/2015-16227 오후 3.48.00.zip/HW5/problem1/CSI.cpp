#include "CSI.h"

Complex::Complex(): real(0), imag(0) {}

CSI::CSI(): data(nullptr), num_packets(0), num_channel(0), num_subcarrier(0) {}

CSI::~CSI() {
    if(data) {
        for(int i = 0 ; i < num_packets; i++) {
            delete[] data[i];
        }
        delete[] data;
    }
}

int CSI::packet_length() const {
    return num_channel * num_subcarrier;
}

void CSI::print(std::ostream& os) const {
    for (int i = 0; i < num_packets; i++) {
        for (int j = 0; j < packet_length(); j++) {
            os << data[i][j] << ' ';
        }
        os << std::endl;
    }
}

std::ostream& operator<<(std::ostream &os, const Complex &c) {
    os << c.real << '+' << c.imag << 'i';
    return os;
}

void read_csi(const char* filename, CSI* csi) {
    std::string str;
    std::ifstream readFile(filename);
    int numOfPackets, numOfChannel, numOfSubcarrier;
    int num = 0;
    while(getline(readFile, str)){
        if(num == 0){
            numOfPackets = std::stoi(str);
        }
        else if(num == 1){
            numOfChannel = std::stoi(str);
        }
        else if(num == 2){
            numOfSubcarrier = std::stoi(str);
            break;
        }
        num++;
    }

    Complex ** data = new Complex*[numOfPackets];
    int row;
    int column;
    for(row = 0; row<numOfPackets; row++) {
        data[row] = new Complex[numOfPackets * numOfChannel];
        for (column = 0; column < numOfSubcarrier * numOfChannel; column++) {
            for(int i = 0 ; i <2; i++) {
                    if (i == 0) {
                        getline(readFile, str);
                        data[row][column].real = std::stoi(str);
                    } else {
                        getline(readFile, str);
                        data[row][column].imag = std::stoi(str);
                    }
            }
        }
    }
    readFile.close();
    csi->data = data;
    csi->num_subcarrier = numOfSubcarrier;
    csi->num_channel = numOfChannel;
    csi->num_packets = numOfPackets;
}


float** decode_csi(CSI* csi) {
    int row = csi->num_packets;
    int column = csi->num_channel * csi->num_subcarrier;
    float** amps = new float*[row];
    for(int i = 0 ; i < row; i++){
        amps[i] = new float[column];
        for(int j = 0; j < column; j++){
            int real = csi->data[i][j].real;
            int comp = csi->data[i][j].imag;
            amps[i][j] = sqrt(real*real + comp*comp);
        }
    }
    return amps;
}

float* get_std(float** decoded_csi, int num_packets, int packet_length) {
    float* stdArray = new float[num_packets];
    for(int i = 0; i < num_packets; i++) {
        stdArray[i] = standard_deviation(decoded_csi[i],packet_length);
    }
    return stdArray;
}

void save_std(float* std_arr, int num_packets, const char* filename) {
    std::ofstream writeFile(filename);
    for(int i = 0; i<num_packets; i++){
        writeFile << std_arr[i] << " ";
    }
    writeFile.close();
}

// convenience functions
float standard_deviation(float* data, int array_length) {
    float mean = 0, var = 0;
    for (int i = 0; i < array_length; i++) {
        mean += data[i];
    }
    mean /= array_length;
    for (int i = 0; i < array_length; i++) {
        var += pow(data[i]-mean,2);
    }
    var /= array_length;
    return sqrt(var);
}